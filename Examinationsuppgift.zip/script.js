// Arrays för att lagra transaktioner
const incomes = [];
const expenses = [];

// Referenser till DOM-element
const descriptionInput = document.getElementById('description');
const amountInput = document.getElementById('amount');
const incomeList = document.getElementById('incomeList');
const expenseList = document.getElementById('expenseList');
const totalDisplay = document.getElementById('total');

const addIncomeBtn = document.getElementById('addIncome');
const addExpenseBtn = document.getElementById('addExpense');

// Funktion för att skapa transaktionsobjekt och lägga till i rätt array
function addTransaction(type) {
    const description = descriptionInput.value.trim();
    const amount = parseFloat(amountInput.value);

    // Validera input
    if (description === '' || isNaN(amount) || amount <= 0) {
        alert('Ange giltig beskrivning och ett belopp större än 0');
        return;
    }

    const transaction = { description, amount, type };

    if (type === 'income') {
        incomes.push(transaction);
    } else if (type === 'expense') {
        expenses.push(transaction);
    }

    clearInputs();
    updateUI();
}

// Rensa inputfält
function clearInputs() {
    descriptionInput.value = '';
    amountInput.value = '';
}

// Uppdatera listorna och total saldo i UI
function updateUI() {
    // Visa inkomster
    incomeList.innerHTML = '';
    incomes.forEach(t => {
        const li = document.createElement('li');
        li.textContent = `${t.description}: +${t.amount.toFixed(2)} kr`;
        li.classList.add('income');
        incomeList.appendChild(li);
    });

    // Visa utgifter
    expenseList.innerHTML = '';
    expenses.forEach(t => {
        const li = document.createElement('li');
        li.textContent = `${t.description}: -${t.amount.toFixed(2)} kr`;
        li.classList.add('expense');
        expenseList.appendChild(li);
    });

    // Beräkna totalt saldo
    const totalIncome = incomes.reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = expenses.reduce((sum, t) => sum + t.amount, 0);
    const total = totalIncome - totalExpenses;

    totalDisplay.textContent = `Totalt saldo: ${total.toFixed(2)} kr`;
    totalDisplay.style.color = total >= 0 ? 'green' : 'red';
}

// Event-lyssnare för knappar
addIncomeBtn.addEventListener('click', () => addTransaction('income'));
addExpenseBtn.addEventListener('click', () => addTransaction('expense'));
